import React, { Component } from 'react';
import Title from './Title';

export default class WarningTitle extends Component {

  render() {
    return (
      <div style={{ border: '1px solid red' }}>
        <Title />
      </div>
    );
  }

}
