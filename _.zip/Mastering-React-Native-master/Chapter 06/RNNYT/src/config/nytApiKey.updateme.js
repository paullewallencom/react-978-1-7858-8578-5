const NYT_API_KEY = 'YOUR_API_KEY_GOES_HERE';
export default NYT_API_KEY;
