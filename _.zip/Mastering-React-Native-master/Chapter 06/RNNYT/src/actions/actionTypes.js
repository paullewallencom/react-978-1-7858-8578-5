export const LOAD_NEWS = 'LOAD_NEWS';
export const SEARCH_NEWS = 'SEARCH_NEWS';
