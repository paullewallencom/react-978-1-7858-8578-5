module.exports = {
  extends: 'eslint-config-ericmasiello'
};
