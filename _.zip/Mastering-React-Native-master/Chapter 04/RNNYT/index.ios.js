/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
import {
  AppRegistry
} from 'react-native';
import HomeScreen from './src/components/HomeScreen';

AppRegistry.registerComponent('RNNYT', () => HomeScreen);
