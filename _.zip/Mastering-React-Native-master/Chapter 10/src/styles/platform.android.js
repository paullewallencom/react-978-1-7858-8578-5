export default {
  PAGE_CONTAINER_STYLE: {
    marginTop: 10,
    marginHorizontal: 10
  },
  TEXT_STYLE: {
    fontFamily: 'sans-serif'
  }
};
