export default {
  PAGE_CONTAINER_STYLE: {
    paddingTop: 20,
    paddingHorizontal: 10,
    marginBottom: 48
  },
  TEXT_STYLE: {
    fontFamily: 'Helvetica Neue'
  }
};
