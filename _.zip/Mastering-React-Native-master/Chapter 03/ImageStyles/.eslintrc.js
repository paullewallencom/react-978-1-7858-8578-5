module.exports = {
  extends: 'eslint-config-ericmasiello',
  rules: {
    'react-native/no-inline-styles': 0,
    'react-native/no-color-literals': 0,
    'global-require': 1
  }
};
