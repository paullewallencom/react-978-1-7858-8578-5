import { AppRegistry } from 'react-native';

// Uncomment these one at a time and update the call to AppRegistry.registerComponent
import DimensionsDemo from './src/DimensionsDemo';
// import OnLayoutDemo from './src/OnLayoutDemo';

AppRegistry.registerComponent('MediaQuery', () => DimensionsDemo);
